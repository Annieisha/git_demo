(req,res) =>{
    res.render('index',{title : 'Home'})
}
(req,res) =>{
    res.render('index',{title : 'About us'})

}
(req,res) =>{
    res.render('index',{title : 'Conatct us'})

}
(req,res) =>{
    res.render('index',{title : 'Services'})
}