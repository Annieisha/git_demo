const express=require('express');
const router = express.Router();
router.get('/',(req,res,next)=>{
    res.render('index',{title:'Home'})
})
router.get('/',(req,res,next)=>{
    res.render('about',{title:'About'})
})
router.get('/',(req,res,next)=>{
    res.render('contactus',{title:'Contact Us'})
})
router.get('/',(req,res,next)=>{
    res.render('services',{title:'Services'})
})
app.get('/', (req, res) => {
   
    const title = 'Anisha Baweja portfolio';
  

    res.render('index', { title: title });
  });
  
module.exports = router;
